-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Mar 14, 2021 at 08:39 AM
-- Server version: 5.7.24
-- PHP Version: 7.2.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shop`
--

-- --------------------------------------------------------

--
-- Table structure for table `address`
--

DROP TABLE IF EXISTS `address`;
CREATE TABLE IF NOT EXISTS `address` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `email` varchar(100) NOT NULL,
  `Clientname` varchar(100) NOT NULL,
  `Phone` varchar(20) NOT NULL,
  `Pin_code` varchar(10) NOT NULL,
  `Home_Number` varchar(100) NOT NULL,
  `Colony` varchar(100) NOT NULL,
  `City` varchar(100) NOT NULL,
  `State` varchar(100) NOT NULL,
  `Type` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `address`
--

INSERT INTO `address` (`id`, `email`, `Clientname`, `Phone`, `Pin_code`, `Home_Number`, `Colony`, `City`, `State`, `Type`) VALUES
(9, 'Shubhamdhoot111@gmail.com', 'shubham dhoot', '6377988343', '342901', 'e18', 'ashapurna city', 'jodhpur', 'rajasthan', 'office'),
(10, 'Shubhamdhoot333@gmail.com', 'shubham dhoot', '6377988343', '342901', 'e18', 'ashapurna city', 'jodhpur', 'rajasthan', 'home');

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
CREATE TABLE IF NOT EXISTS `admin` (
  `email` varchar(255) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`email`, `password`) VALUES
('shubhamdhoot333@gmail.com', '03032000');

-- --------------------------------------------------------

--
-- Table structure for table `card`
--

DROP TABLE IF EXISTS `card`;
CREATE TABLE IF NOT EXISTS `card` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `product_id` varchar(20) NOT NULL,
  `cost` varchar(25) NOT NULL,
  `title` varchar(100) NOT NULL,
  `data` varchar(255) NOT NULL,
  `photo1` varchar(255) NOT NULL,
  `photo2` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `card`
--

INSERT INTO `card` (`id`, `name`, `email`, `product_id`, `cost`, `title`, `data`, `photo1`, `photo2`) VALUES
(4, 'chocolate cake', 'Shubhamdhoot333@gmail.com', '4 ', '300', 'Birthday cake', 'this is very testy cast for birthday', '../image/c3.jpg', '../image/c8.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `order_table`
--

DROP TABLE IF EXISTS `order_table`;
CREATE TABLE IF NOT EXISTS `order_table` (
  `order_no` int(255) NOT NULL AUTO_INCREMENT,
  `product_id` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `date1` date NOT NULL,
  `address` varchar(255) NOT NULL,
  `quantity` varchar(100) NOT NULL,
  `cost` varchar(100) NOT NULL,
  `stage` varchar(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `photo1` varchar(255) NOT NULL,
  `uname` varchar(255) NOT NULL,
  PRIMARY KEY (`order_no`)
) ENGINE=MyISAM AUTO_INCREMENT=29 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `order_table`
--

INSERT INTO `order_table` (`order_no`, `product_id`, `name`, `date1`, `address`, `quantity`, `cost`, `stage`, `email`, `phone`, `photo1`, `uname`) VALUES
(28, '4       ', 'chocolate cake', '2021-03-14', 'e18  ,ashapurna city  ,jodhpur  ,rajasthan  ,', '1  ', '300', '', 'Shubhamdhoot333@gmail.com', '6377988343', '../image/c3.jpg', 'shubham dhoot'),
(19, '4     ', 'chocolate cake', '2021-03-13', 'e18  ,ashapurna city  ,jodhpur  ,rajasthan  ,', '1  ', '300', '', 'Shubhamdhoot111@gmail.com', '6377988343', '../image/c3.jpg', 'shubham dhoot'),
(20, '4      ', 'chocolate cake', '2021-03-13', 'e18  ,ashapurna city  ,jodhpur  ,rajasthan  ,', '1  ', '300', '', 'Shubhamdhoot111@gmail.com', '6377988343', '../image/c3.jpg', 'shubham dhoot');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
CREATE TABLE IF NOT EXISTS `product` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `name` varchar(40) NOT NULL,
  `product_id` varchar(20) NOT NULL,
  `cost` varchar(20) NOT NULL,
  `data` varchar(255) NOT NULL,
  `photo1` varchar(255) NOT NULL,
  `photo2` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `title`, `name`, `product_id`, `cost`, `data`, `photo1`, `photo2`) VALUES
(3, 'cake', 'cake', '3', '200', 'hiii', '../image/a9.jpg', '../image/a7.jpg'),
(4, 'Birthday cake', 'chocolate cake', '4', '300', 'this is very testy cast for birthday', '../image/c3.jpg', '../image/c8.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `review`
--

DROP TABLE IF EXISTS `review`;
CREATE TABLE IF NOT EXISTS `review` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `story` varchar(255) NOT NULL,
  `stage` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `review`
--

INSERT INTO `review` (`id`, `email`, `story`, `stage`) VALUES
(1, 'Shubhamdhoot333@gmail.com', 'hiii your product is awsem', 'good');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `Phone` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `pass` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `name`, `Phone`, `email`, `pass`) VALUES
(1, 'shubham', '9829180368', 'Shubhamdhoot333@gmail.com', '03032000'),
(2, 'shubham dhoot', '6377988343', 'shubhamdhoot111@gmail.com', '03032000'),
(3, 'shubham', '6377988343', 'Shubhamdhoot101@gmail.com', '03032000');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
